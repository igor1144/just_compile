# Наследование базовой 64-битной архитектуры
$(call inherit-product, $(SRC_TARGET_DIR)/product/core_64_bit.mk)

# Поддержка Virtual A/B OTA для Android 15 (Обязательно для HyperOS 2.0)
$(call inherit-product, $(SRC_TARGET_DIR)/product/virtual_ab_ota/android_twrp.mk)

# Инсталляция GSI ключей в рамдиск (оставляем, если нужно для тестов)
#$(call inherit-product, $(SRC_TARGET_DIR)/product/gsi_keys.mk)

# Наследование общих конфигураций TWRP
$(call inherit-product, vendor/twrp/config/common.mk)

# Наследование спецификаций самого устройства
$(call inherit-product, device/xiaomi/sea/device.mk)

# Основные свойства продукта
PRODUCT_DEVICE := sea
PRODUCT_NAME := twrp_sea
PRODUCT_BRAND := Xiaomi
PRODUCT_MANUFACTURER := Xiaomi
PRODUCT_RELEASE_NAME := sea

PRODUCT_GMS_CLIENTID_BASE := android-xiaomi
