LOCAL_PATH := device/xiaomi/sea

# Включение динамических разделов
PRODUCT_USE_DYNAMIC_PARTITIONS := true

# Уровень API (соответствует Android 12 при выходе устройства, оставляем)
PRODUCT_SHIPPING_API_LEVEL := 31

# Пространство имен Soong
PRODUCT_SOONG_NAMESPACES += \
    $(LOCAL_PATH)

# Базовые утилиты для работы с разметкой MediaTek
# PRODUCT_PACKAGES += \
    create_pl_dev \
    create_pl_dev.recovery

# Fastbootd (Необходим для прошивки логических разделов)
PRODUCT_PACKAGES += \
    android.hardware.fastboot@1.1-impl-mock \
    fastbootd

# Служебные библиотеки для шифрования/декрипта
# Даже если crypto=false, TWRP часто требует их наличия для линковки компонентов vold
# PRODUCT_PACKAGES += \
    libkeymaster4 \
    libkeymaster41 \
    libpuresoftkeymasterdevice \
    libkeymaster_messages.vendor \
    libion \
    libxml2

# Копирование общих библиотек в recovery ramdisk
RECOVERY_LIBRARY_SOURCE_FILES += \
    $(TARG,ET_OUT_SHARED_LIBRARIES)/libion.so \
    $(TARGET_OUT_SHARED_LIBRARIES)/libxml2.so
#    $(TARGET_OUT_SHARED_LIBRARIES)/libkeymaster4.so \
#    $(TARGET_OUT_SHARED_LIBRARIES)/libkeymaster41.so \
#    $(TARGET_OUT_SHARED_LIBRARIES)/libpuresoftkeymasterdevice.so \
#    $(TARGET_OUT_SHARED_LIBRARIES)/libkeymaster_messages.so \
